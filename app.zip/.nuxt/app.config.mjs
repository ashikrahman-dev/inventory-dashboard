
import { defuFn } from 'D:/Ashik/projects/nuxt-js/inventory-dashboard/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
