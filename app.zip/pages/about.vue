<template>
    <nav>
            <ul class="grid grid-cols-6 gap-2 bg-amber-100 text-amber-800 p-4">
                <li><NuxtLink to="/">Home</NuxtLink></li>
                <li><NuxtLink to="/about">About</NuxtLink></li>
                <li><NuxtLink to="/products">Products</NuxtLink></li>
                <li><NuxtLink to="/login">Login</NuxtLink></li>
            </ul>
        </nav>
    <div class=" bg-orange-900 text-yellow-50 p-8">
        <h1 class="text-4xl font-bold">About page</h1>
        <p class="text-2xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit animi, numquam culpa molestiae veniam autem ab vel aspernatur quaerat libero. Reiciendis officiis dolor vero vel ea eum earum quidem ad itaque corrupti a quod officia necessitatibus provident incidunt non quam maiores ut, tenetur, voluptas aliquid? Enim atque ullam architecto, praesentium eveniet asperiores blanditiis animi nulla aliquid? Et iure enim at doloribus repellat debitis officia, possimus dicta nobis totam error accusantium autem velit ipsam laudantium laboriosam minima beatae asperiores dolore. Tempora ab, voluptatibus distinctio corrupti atque quo nesciunt laborum aut corporis quidem debitis enim molestias illum aperiam odit sunt? Impedit, nesciunt!</p>
        <p class="text-2xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit animi, numquam culpa molestiae veniam autem ab vel aspernatur quaerat libero. Reiciendis officiis dolor vero vel ea eum earum quidem ad itaque corrupti a quod officia necessitatibus provident incidunt non quam maiores ut, tenetur, voluptas aliquid? Enim atque ullam architecto, praesentium eveniet asperiores blanditiis animi nulla aliquid? Et iure enim at doloribus repellat debitis officia, possimus dicta nobis totam error accusantium autem velit ipsam laudantium laboriosam minima beatae asperiores dolore. Tempora ab, voluptatibus distinctio corrupti atque quo nesciunt laborum aut corporis quidem debitis enim molestias illum aperiam odit sunt? Impedit, nesciunt!</p>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>