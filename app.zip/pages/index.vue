<template>
    <div>
        <nav>
            <ul class="grid grid-cols-6 gap-2 bg-amber-100 text-amber-800 p-4">
                <li><NuxtLink to="/">Home</NuxtLink></li>
                <li><NuxtLink to="/about">About</NuxtLink></li>
                <li><NuxtLink to="/products">Products</NuxtLink></li>
                <li><NuxtLink to="/login">Login</NuxtLink></li>
            </ul>
        </nav>
        <h1>Home page</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Optio porro quos perspiciatis. Autem assumenda pariatur necessitatibus ipsa harum quisquam! Reiciendis nulla neque iste animi, eius fugiat incidunt necessitatibus ut excepturi?</p>
    </div>
</template>

<script setup>

   

</script>

<style scoped>

</style>