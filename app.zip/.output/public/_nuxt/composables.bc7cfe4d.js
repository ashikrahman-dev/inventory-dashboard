import{l as r}from"./entry.92e619bf.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
