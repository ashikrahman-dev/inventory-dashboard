const e=""+new URL("logo.d6e8fe78.svg",import.meta.url).href;export{e as _};
