const index_vue_vue_type_style_index_0_scoped_c559b50f_lang = ".login-bg[data-v-c559b50f]{background:url(" + globalThis.__buildAssetsURL("login-bg.33d2be44.jpg") + ");background-position:50%;background-repeat:no-repeat;background-size:cover}.login-wrap[data-v-c559b50f]{border-radius:20px;padding:50px}";

const indexStyles_5d8d916f = [index_vue_vue_type_style_index_0_scoped_c559b50f_lang];

export { indexStyles_5d8d916f as default };
//# sourceMappingURL=index-styles.5d8d916f.mjs.map
