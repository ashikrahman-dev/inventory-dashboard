const _imports_0 = "" + globalThis.__buildAssetsURL("logo.d6e8fe78.svg");

export { _imports_0 as _ };
//# sourceMappingURL=logo.f6a91fcf.mjs.map
