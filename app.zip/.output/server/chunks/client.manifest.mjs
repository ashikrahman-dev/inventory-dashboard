const client_manifest = {
  "assets/img/logo.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "logo.d6e8fe78.svg",
    "src": "assets/img/logo.svg"
  },
  "assets/img/login-bg.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "login-bg.33d2be44.jpg",
    "src": "assets/img/login-bg.jpg"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.92e619bf.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "virtual:nuxt:D:/Ashik/projects/nuxt-js/inventory-dashboard/.nuxt/error-component.mjs"
    ],
    "css": [
      "entry.95d6d3d3.css"
    ]
  },
  "entry.95d6d3d3.css": {
    "file": "entry.95d6d3d3.css",
    "resourceType": "style"
  },
  "virtual:nuxt:D:/Ashik/projects/nuxt-js/inventory-dashboard/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.0ba19feb.js",
    "src": "virtual:nuxt:D:/Ashik/projects/nuxt-js/inventory-dashboard/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "file": "about.6a36ecfd.js",
    "src": "pages/about.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.3e16e60f.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/login/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.8ec39bd4.js",
    "src": "pages/login/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_logo.f6a91fcf.js"
    ],
    "css": [],
    "assets": [
      "login-bg.33d2be44.jpg"
    ]
  },
  "index.fee0313c.css": {
    "file": "index.fee0313c.css",
    "resourceType": "style"
  },
  "login-bg.33d2be44.jpg": {
    "file": "login-bg.33d2be44.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "_logo.f6a91fcf.js": {
    "resourceType": "script",
    "module": true,
    "file": "logo.f6a91fcf.js",
    "assets": [
      "logo.d6e8fe78.svg"
    ]
  },
  "logo.d6e8fe78.svg": {
    "file": "logo.d6e8fe78.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "pages/registration/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.66e5da04.js",
    "src": "pages/registration/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_logo.f6a91fcf.js"
    ],
    "css": [],
    "assets": [
      "login-bg.33d2be44.jpg"
    ]
  },
  "index.fe2ad031.css": {
    "file": "index.fe2ad031.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.a4312b81.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_composables.bc7cfe4d.js"
    ],
    "css": []
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "_composables.bc7cfe4d.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.bc7cfe4d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.aa0130d2.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_composables.bc7cfe4d.js",
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "pages/registration/index.css": {
    "resourceType": "style",
    "file": "index.fe2ad031.css",
    "src": "pages/registration/index.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "pages/login/index.css": {
    "resourceType": "style",
    "file": "index.fee0313c.css",
    "src": "pages/login/index.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.95d6d3d3.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
