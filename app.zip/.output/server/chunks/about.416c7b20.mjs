import { _ as _export_sfc, a as __nuxt_component_0$1 } from './server.mjs';
import { withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<!--[--><nav><ul class="grid grid-cols-6 gap-2 bg-amber-100 text-amber-800 p-4"><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Home`);
      } else {
        return [
          createTextVNode("Home")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/about" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`About`);
      } else {
        return [
          createTextVNode("About")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/products" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Products`);
      } else {
        return [
          createTextVNode("Products")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/login" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Login`);
      } else {
        return [
          createTextVNode("Login")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></nav><div class="bg-orange-900 text-yellow-50 p-8"><h1 class="text-4xl font-bold">About page</h1><p class="text-2xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit animi, numquam culpa molestiae veniam autem ab vel aspernatur quaerat libero. Reiciendis officiis dolor vero vel ea eum earum quidem ad itaque corrupti a quod officia necessitatibus provident incidunt non quam maiores ut, tenetur, voluptas aliquid? Enim atque ullam architecto, praesentium eveniet asperiores blanditiis animi nulla aliquid? Et iure enim at doloribus repellat debitis officia, possimus dicta nobis totam error accusantium autem velit ipsam laudantium laboriosam minima beatae asperiores dolore. Tempora ab, voluptatibus distinctio corrupti atque quo nesciunt laborum aut corporis quidem debitis enim molestias illum aperiam odit sunt? Impedit, nesciunt!</p><p class="text-2xl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit animi, numquam culpa molestiae veniam autem ab vel aspernatur quaerat libero. Reiciendis officiis dolor vero vel ea eum earum quidem ad itaque corrupti a quod officia necessitatibus provident incidunt non quam maiores ut, tenetur, voluptas aliquid? Enim atque ullam architecto, praesentium eveniet asperiores blanditiis animi nulla aliquid? Et iure enim at doloribus repellat debitis officia, possimus dicta nobis totam error accusantium autem velit ipsam laudantium laboriosam minima beatae asperiores dolore. Tempora ab, voluptatibus distinctio corrupti atque quo nesciunt laborum aut corporis quidem debitis enim molestias illum aperiam odit sunt? Impedit, nesciunt!</p></div><!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const about = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { about as default };
//# sourceMappingURL=about.416c7b20.mjs.map
