import { _ as _export_sfc, a as __nuxt_component_0$1 } from './server.mjs';
import { resolveComponent, mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo.f6a91fcf.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_LockClosedIcon = resolveComponent("LockClosedIcon");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "login-bg h-screen grid items-center" }, _attrs))} data-v-c559b50f><div class="xl:container mx-auto" data-v-c559b50f><div class="py-12 px-4 sm:px-6 lg:px-8" data-v-c559b50f><div class="w-full max-w-md space-y-8 login-wrap bg-white" data-v-c559b50f><div data-v-c559b50f><img class="h-6 w-auto"${ssrRenderAttr("src", _imports_0)} alt="Your Company" data-v-c559b50f><h2 class="mt-6 text-4xl font-bold tracking-tight text-gray-900" data-v-c559b50f>Sign in</h2></div><form class="mt-8 space-y-6" action="#" method="POST" data-v-c559b50f><input type="hidden" name="remember" value="true" data-v-c559b50f><div class="-space-y-px rounded-md shadow-sm" data-v-c559b50f><div data-v-c559b50f><label for="email-address" class="text-gray-900" data-v-c559b50f>Email</label><input id="email-address" name="email" type="email" autocomplete="email" required="" class="relative block w-full appearance-none rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm" placeholder="Email address" data-v-c559b50f></div><div data-v-c559b50f><label for="password" class="text-gray-900" data-v-c559b50f>Password</label><input id="password" name="password" type="password" autocomplete="current-password" required="" class="relative block w-full appearance-none rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:z-10 focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm" placeholder="Password" data-v-c559b50f></div></div><div class="flex items-center justify-between" data-v-c559b50f><div class="flex items-center" data-v-c559b50f><input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" data-v-c559b50f><label for="remember-me" class="ml-2 block text-sm text-gray-900" data-v-c559b50f>Remember me</label></div><div class="text-sm" data-v-c559b50f><a href="#" class="font-medium text-indigo-600 hover:text-indigo-500" data-v-c559b50f>Forgot your password?</a></div></div><div class="grid gap-4" data-v-c559b50f>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/login" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="submit" class="group relative flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2" data-v-c559b50f${_scopeId}><span class="absolute inset-y-0 left-0 flex items-center pl-3" data-v-c559b50f${_scopeId}>`);
            _push2(ssrRenderComponent(_component_LockClosedIcon, {
              class: "h-5 w-5 text-indigo-500 group-hover:text-indigo-400",
              "aria-hidden": "true"
            }, null, _parent2, _scopeId));
            _push2(`</span> Sign in </button>`);
          } else {
            return [
              createVNode("button", {
                type: "submit",
                class: "group relative flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
              }, [
                createVNode("span", { class: "absolute inset-y-0 left-0 flex items-center pl-3" }, [
                  createVNode(_component_LockClosedIcon, {
                    class: "h-5 w-5 text-indigo-500 group-hover:text-indigo-400",
                    "aria-hidden": "true"
                  })
                ]),
                createTextVNode(" Sign in ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/registration" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="submit" class="group relative flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2" data-v-c559b50f${_scopeId}><span class="absolute inset-y-0 left-0 flex items-center pl-3" data-v-c559b50f${_scopeId}>`);
            _push2(ssrRenderComponent(_component_LockClosedIcon, {
              class: "h-5 w-5 text-indigo-500 group-hover:text-indigo-400",
              "aria-hidden": "true"
            }, null, _parent2, _scopeId));
            _push2(`</span> registration </button>`);
          } else {
            return [
              createVNode("button", {
                type: "submit",
                class: "group relative flex w-full justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
              }, [
                createVNode("span", { class: "absolute inset-y-0 left-0 flex items-center pl-3" }, [
                  createVNode(_component_LockClosedIcon, {
                    class: "h-5 w-5 text-indigo-500 group-hover:text-indigo-400",
                    "aria-hidden": "true"
                  })
                ]),
                createTextVNode(" registration ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></form></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/login/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-c559b50f"]]);

export { index as default };
//# sourceMappingURL=index.721095c7.mjs.map
