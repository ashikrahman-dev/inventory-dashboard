const index_vue_vue_type_style_index_0_scoped_843656a3_lang = ".login-bg[data-v-843656a3]{background:url(" + globalThis.__buildAssetsURL("login-bg.33d2be44.jpg") + ");background-position:50%;background-repeat:no-repeat;background-size:cover}.login-wrap[data-v-843656a3]{border-radius:20px;padding:50px}";

const indexStyles_dd8b7cb8 = [index_vue_vue_type_style_index_0_scoped_843656a3_lang];

export { indexStyles_dd8b7cb8 as default };
//# sourceMappingURL=index-styles.dd8b7cb8.mjs.map
